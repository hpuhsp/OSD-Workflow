# OSD Workflow 内部推广演示大纲

1. OSD Workflow：让 AI 开发从“会写代码”变成“可交付”
2. 组织需要的不是更多流程，而是稳定的交付结果
3. OpenSpec：把意图写成可验收的变更契约
4. Superpowers：把契约落成可执行的工程步骤
5. 整套工作流的全景图：先路由，再委派，最后交付证据
6. OSD 是轻控制平面：先路由，再委派
7. 三种能力各司其职：OSD、OpenSpec、Superpowers
8. 任务不同，模式和策略就不同
9. 三种模式：lite、standard、strict
10. 三种开发策略：tdd、test_first、verification_only
11. 一次任务如何运行：从普通请求到验证证据
12. 产物随风险增长，不让文档反客为主
13. 接入项目：一个 AGENTS.md，保留 Agent 选择权
14. 从一个小范围试点开始
